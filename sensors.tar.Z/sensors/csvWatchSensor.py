from os.path  import isfile,  join
from os import listdir
import os, eventlet
from st2reactor.sensor.base import Sensor

class csvWatchSensor(Sensor):
    def __init__(self, sensor_service, config):
        super(csvWatchSensor, self).__init__(sensor_service=sensor_service, config=config)
        self._logger = self.sensor_service.get_logger(name=self.__class__.__name__)
        self._stop = False

    def setup(self):
        pass

    def run(self):
        mypath = "/home/st2/addXmcDevices/"
        self._logger.debug('csvWatchSensor run...')

        while not self._stop:
            self._logger.debug('csvWatchSensor looping...')
            
            # scan the directory for csv files
            onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]

            # filter on only csv files
            for f in onlyfiles:
                if ".csv" in f:
                    print("File is -> %s " % f)
                    #only trigger on files that have content
                    if os.path.getsize(mypath+f) > 0:
                        # get the files contents
                        # prepare the contents for injection to the workflow
                        with open (mypath+f, "r") as myfile:
                            data=myfile.readlines()
                        # dispatch the trigger and inject the data
                        self._logger.debug('csvWatchSensor dispatching trigger...')
                        count = self.sensor_service.get_value('csvWatchSensor.count') or 0
                        payload = {'csvFile': str(f), 'devices': str(data), 'counter': int(count) + 1}
                        self.sensor_service.dispatch(trigger='my_xmc.csvWatchSensor', payload=payload)
                        self.sensor_service.set_value('csvWatchSensor.count', payload['count'])
                        # Change the filename
                        os.rename(mypath+f, mypath+f+"processed")
                    else:
                        print("Skipping %s file too small " %mypath+f)
            
            eventlet.sleep(60)   

    def cleanup(self):
        self._stop = True

    # Methods required for programmable sensors.
    def add_trigger(self, trigger):
        pass

    def update_trigger(self, trigger):
        pass

    def remove_trigger(self, trigger):
        pass
